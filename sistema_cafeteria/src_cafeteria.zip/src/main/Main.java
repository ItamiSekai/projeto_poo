package main;

import frames.CozinheiroFrame;
import frames.LoginFrame;

public class Main {

	public static void main(String[] args) {
		
		LoginFrame frame = new LoginFrame();
		//RHFrame frame = new RHFrame();
		//CozinheiroFrame frame = new CozinheiroFrame();
		
	}

}
